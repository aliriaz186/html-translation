@extends('layouts.app')

@section('content')

<!-- Basic Data Tables -->
<!--===================================================-->
<div class="panel">
    <div class="panel-heading bord-btm clearfix pad-all h-100">
        <h3 class="panel-title pull-left pad-no">{{__('Customers Feedbacks')}}</h3>
    </div>
    <div class="panel-body">
        <table class="table table-striped res-table mar-no" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>{{__('Prodcut Name')}}</th>
                    <th>{{__('Customer Email')}}</th>
                    <th>{{__('Seller Email')}}</th>
                    <th>{{__('Message')}}</th>
                    <th>{{__('Ratting')}}</th>
                    <th>{{__('Status')}}</th>
                    <th width="10%">{{__('Options')}}</th>
                </tr>
            </thead>
            <tbody>
                @foreach($feedbacks as $key => $feedback)
                    <tr>
                        <td>{{ ($key+1) + ($feedbacks->currentPage() - 1)*$feedbacks->perPage() }}</td>
                        <td>{{$feedback->product->name}}</td>
                        <td>{{$feedback->customer->user->email}}</td>
                        <td>{{$feedback->seller->user->email}}</td>
                        <td>{{$feedback->feedback}}</td>
                        <td>
                            <span class="star-rating star-rating-sm d-block">
                                @if ($feedback->rating > 0)
                                {{ renderStarRating($feedback->rating) }}
                                @else
                                    {{ renderStarRating(0) }}
                                @endif
                            </span>
                        </td>
                        <td>
                                <label class="switch">
                                    <input type="checkbox" value="{{$feedback->id}}" onchange="update_feedback(this)" {{$feedback->status == 1 ? 'checked' : ''}}>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                        <td>
                            <div class="btn-group dropdown">
                                <button class="btn btn-primary dropdown-toggle dropdown-toggle-icon" data-toggle="dropdown" type="button">
                                    {{__('Actions')}} <i class="dropdown-caret"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a onclick="confirm_modal('{{route('admin.customer_feedback_destroy', $feedback->id)}}');">{{__('Delete')}}</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="clearfix">
            <div class="pull-right">
                {{ $feedbacks->appends(request()->input())->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
            function update_feedback(el){
            if(el.checked){
                var status = 1;
            }
            else{
                var status = 0;
            }
            $.get('{{ route('admin.customer_feedback_status') }}', {_token:'{{ csrf_token() }}', id:el.value, status:status}, function(data){
                if(data == 1){
                    showAlert('success', 'Feedback set successfully');
                    location.reload();
                }
                else{
                    showAlert('danger', 'Something went wrong');
                    location.reload();

                }
            });
        }
</script>
@endsection
