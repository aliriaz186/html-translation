@extends('frontend.layouts.app')

@section('content')

    <section class="gry-bg py-4 profile">
        <div class="container">
            <div class="row cols-xs-space cols-sm-space cols-md-space">
                <div class="col-lg-3 d-none d-lg-block">
                    @include('frontend.inc.seller_side_nav')
                </div>

                <div class="col-lg-9">
                    <!-- Page title -->
                    <div class="page-title">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h2 class="heading heading-6 text-capitalize strong-600 mb-0">
                                    {{__('Import Data')}}
                                </h2>
                            </div>
                            <div class="col-md-6">
                                <div class="float-md-right">
                                    <ul class="breadcrumb">
                                        <li><a href="{{ route('home') }}">{{__('Home')}}</a></li>
                                        <li class="active"><a href="{{ route('import_data.index') }}">{{__('Import Data')}}</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <div class="dashboard-widget text-center  mt-4 c-pointer">
                                    <a href="{{route('import_data.magento')}}" class="d-block">
                                        <img src="https://nanowebgroup.com/wp-content/uploads/2013/04/Magento-icon.png" alt="" class="img">
                                        <span class="d-block title heading-3 strong-400">Magento</span>
                                        <span class="d-block sub-title">{{__('Framework')}}</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="dashboard-widget text-center  mt-4 c-pointer">
                                    <a href="{{route('import_data.ebay')}}" class="d-block">
                                        <img src="https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/ebay-512.png" alt="" class="img">
                                        <span class="d-block title heading-3 strong-400">Ebay</span>
                                        <span class="d-block sub-title">{{__('Market Place')}}</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="dashboard-widget text-center  mt-4 c-pointer">
                                    <a href="{{route('import_data.wordpress')}}" class="d-block">
                                        <img src="https://img.pngio.com/wordpress-icon-papirus-apps-iconset-papirus-development-team-wordpress-icon-png-512_512.png" class="img" alt="">
                                        <span class="d-block title heading-3 strong-400">Wordpress</span>
                                        <span class="d-block sub-title">{{__('ERP')}}</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="dashboard-widget text-center mt-4 c-pointer">
                                    <a href="{{route('import_data.shopify')}}" class="d-block">
                                        <img src="https://cdn3.iconfinder.com/data/icons/social-media-2068/64/_shopping-512.png" alt="" class="img">
                                        <span class="d-block title heading-3 strong-400">Shopify</span>
                                        <span class="d-block sub-title">{{__('ERP')}}</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
